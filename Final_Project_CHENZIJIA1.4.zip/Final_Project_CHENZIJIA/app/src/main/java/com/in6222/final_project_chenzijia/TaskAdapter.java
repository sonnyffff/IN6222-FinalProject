package com.in6222.final_project_chenzijia;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.EditText;
import android.app.AlertDialog;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.List;
import android.util.Log;

import com.google.android.material.snackbar.Snackbar;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private List<Task> taskList;
    private Context context;
    private List<Task> completedTaskList; // 存储已完成的任务列表
    private List<Task> pendingTaskList; // 存储未完成的任务列表

    private TaskDatabaseHelper dbHelper; // SQLite数据库操作

    public TaskAdapter(List<Task> taskList, Context context, List<Task> completedTaskList, List<Task> pendingTaskList) {
        this.taskList = taskList;
        this.context = context;
        this.completedTaskList = completedTaskList;
        this.pendingTaskList = pendingTaskList;

        this.dbHelper = new TaskDatabaseHelper(context); // 初始化数据库操作类
    }


    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.task_item, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.taskNameTextView.setText(task.getTaskName());

        // 点击任务名称以编辑
        holder.taskNameTextView.setOnClickListener(v -> showEditTaskDialog(task, holder.getBindingAdapterPosition()));

        // 设置分组
        holder.taskCheckBox.setOnCheckedChangeListener(null); // 首先移除监听器
        holder.taskCheckBox.setChecked(task.isCompleted()); // 设置任务的状态

        holder.taskCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            task.setCompleted(isChecked);
            Log.d("TaskAdapter", "Task: " + task.getTaskName() + " checked: " + isChecked);

            // 使用 post 方法来确保在 RecyclerView 完成布局时执行更新
            holder.taskCheckBox.post(() -> {
                if (isChecked) {
                    // 从未完成列表移动到已完成列表

                    pendingTaskList.remove(task);
                    completedTaskList.add(task);
                } else {
                    // 从已完成列表移动到未完成列表

                    completedTaskList.remove(task);
                    pendingTaskList.add(task);
                }

                // 更新 SQLite 数据库
                dbHelper.updateTask(task); // 更新任务状态
                // 更新 RecyclerView
                notifyDataSetChanged(); // 你可以选择 notifyItemChanged(position);
            });
        });

    }

    public void setupItemTouchHelper(RecyclerView recyclerView) {
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                int fromPosition = viewHolder.getBindingAdapterPosition();
                int toPosition = target.getBindingAdapterPosition();
                if (fromPosition != RecyclerView.NO_POSITION && toPosition != RecyclerView.NO_POSITION) {
                    // 处理任务顺序移动
                    onItemMove(fromPosition, toPosition);
                    return true; // 返回 true 表示移动成功
                }
                return false; // 移动失败
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    deleteTask(position, recyclerView); // 删除任务
                }
            }

            @Override
            public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                // 自定义滑动背景效果
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
                    Paint paint = new Paint();
                    if (dX < 0) { // 向左滑动
                        paint.setColor(Color.RED); // 红色背景
                        c.drawRect(viewHolder.itemView.getRight() + dX, viewHolder.itemView.getTop(), viewHolder.itemView.getRight(), viewHolder.itemView.getBottom(), paint);

                        // 绘制垃圾箱图标
                        Bitmap trashIcon = BitmapFactory.decodeResource(recyclerView.getResources(), R.drawable.img); // 请确保您有垃圾箱图标的资源
                        if (trashIcon != null) { // 检查图标是否加载成功
                            float iconWidth = trashIcon.getWidth();
                            float iconHeight = trashIcon.getHeight();
                            float iconMargin = (viewHolder.itemView.getHeight() - iconHeight) / 2; // 垂直居中
                            c.drawBitmap(trashIcon, viewHolder.itemView.getRight() - iconWidth - 16, viewHolder.itemView.getTop() + iconMargin, null); // 显示垃圾箱图标
                        } else {
                            Log.e("TaskAdapter", "Error: trash icon is null. Check if the resource exists.");
                        }
                    }
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            }
        });

        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

public void deleteTask(int position, RecyclerView recyclerView) {
    if (position >= 0 && position < taskList.size()) {
        Task removedTask = taskList.get(position); // 获取要删除的任务
        taskList.remove(position); // 从任务列表中移除

        // 检查任务是否在已完成列表中
        if (completedTaskList.contains(removedTask)) {
            completedTaskList.remove(removedTask); // 从已完成列表中移除
        } else {
            pendingTaskList.remove(removedTask); // 从未完成列表中移除
        }

        notifyItemRemoved(position); // 通知适配器删除
        dbHelper.deleteTask(removedTask.getTaskName(), removedTask.isCompleted()); // 从数据库中删除任务

        // 显示 Snackbar
        Snackbar snackbar = Snackbar.make(recyclerView, "Task deleted", Snackbar.LENGTH_LONG)
                .setAction("UNDO", v -> {
                    // 用户点击撤销
                    taskList.add(position, removedTask); // 将任务重新添加到列表
                    if (removedTask.isCompleted()) {
                        completedTaskList.add(removedTask); // 重新添加到已完成列表
                    } else {
                        pendingTaskList.add(removedTask); // 重新添加到未完成列表
                    }
                    dbHelper.addTask(removedTask);
                    notifyItemInserted(position); // 通知适配器更新
                });
        snackbar.show(); // 显示 Snackbar
    }
}


    @Override
    public int getItemCount() {
        return taskList.size();
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView taskNameTextView;
        CheckBox taskCheckBox;
        ImageButton deleteButton;

        public TaskViewHolder(View itemView) {
            super(itemView);
            taskNameTextView = itemView.findViewById(R.id.taskNameTextView);
            taskCheckBox = itemView.findViewById(R.id.taskCheckBox);
            //deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    // 单击名称修改
    private void showEditTaskDialog(Task task, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Task");

        // 输入框
        final EditText input = new EditText(context);
        input.setText(task.getTaskName());
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String updatedTaskName = input.getText().toString();
            if (!updatedTaskName.isEmpty()) {
                task.setTaskName(updatedTaskName); // 更新任务名称
                dbHelper.updateTask(task); // 更新数据库
                notifyItemChanged(position); // 通知适配器更新
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
    
    // 添加拖动功能
    public void onItemMove(int fromPosition, int toPosition) {
        // 检查索引范围
        if (fromPosition < 0 || toPosition < 0 || fromPosition >= taskList.size() || toPosition >= taskList.size()) {
            return; // 超出范围，不处理
        }

        // 输出调试信息
        Log.d("TaskAdapter", "Moving from position: " + fromPosition + " to position: " + toPosition);
        Log.d("TaskAdapter", "Current task list size: " + taskList.size());

        // 处理移动逻辑
        if (fromPosition < toPosition) {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(taskList, i, i + 1);
            }
        } else {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(taskList, i, i - 1);
            }
        }

        // 通知适配器更新
        notifyItemMoved(fromPosition, toPosition);
    }

    // 筛选
    public void updateTaskList(List<Task> newTaskList) {
        this.taskList.clear();
        this.taskList.addAll(newTaskList);
        notifyDataSetChanged(); // 通知适配器数据已更改
    }


}
