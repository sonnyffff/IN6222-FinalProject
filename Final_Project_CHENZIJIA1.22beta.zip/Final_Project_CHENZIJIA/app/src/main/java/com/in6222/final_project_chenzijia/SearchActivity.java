package com.in6222.final_project_chenzijia;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {
    private EditText searchEditText;
    private RecyclerView searchResultsRecyclerView;
    private TaskAdapter taskAdapter;
    private List<Task> allTasks; // 这是保存所有任务的列表
    private List<Task> filteredTasks; // 这是搜索结果

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        searchEditText = findViewById(R.id.searchEditText);
        searchResultsRecyclerView = findViewById(R.id.searchResultsRecyclerView);
        searchResultsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 假设您在其他地方填充了 allTasks 列表
        allTasks = (List<Task>) getIntent().getSerializableExtra("ALL_TASKS");
        filteredTasks = new ArrayList<>();

        // 设置适配器
        taskAdapter = new TaskAdapter(filteredTasks, this, new ArrayList<>(), new ArrayList<>());
        searchResultsRecyclerView.setAdapter(taskAdapter);

        // 添加 TextWatcher
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterTasks(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish()); // 返回上一个 Activity
    }

    // 根据输入过滤任务
    private void filterTasks(String query) {

        filteredTasks.clear();

        List<Task> filteredTasks = new ArrayList<>();
        if (query.isEmpty()) {
            // 如果搜索框为空，则不显示任何任务
            taskAdapter.updateTaskList(new ArrayList<>());
        } else {
            // 根据查询过滤任务
            for (Task task : allTasks) {
                if (task.getTaskName().toLowerCase().contains(query)) {
                    filteredTasks.add(task);
                }
            }

            taskAdapter.updateTaskList(filteredTasks); // 更新搜索结果
        }

    }
}


