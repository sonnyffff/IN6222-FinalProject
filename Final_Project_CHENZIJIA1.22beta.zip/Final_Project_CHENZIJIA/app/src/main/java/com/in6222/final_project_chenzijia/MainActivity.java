package com.in6222.final_project_chenzijia;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import androidx.recyclerview.widget.ItemTouchHelper;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;


public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private TaskAdapter taskAdapter;
    private List<Task> taskList; // 存储任务列表
    private FloatingActionButton fab; // 添加任务的按钮
    private List<Task> pendingTaskList; // 存储未完成的任务列表
    private List<Task> completedTaskList; // 存储已完成的任务列表

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        taskList = new ArrayList<>(); // 确保创建了 ArrayList
        pendingTaskList = new ArrayList<>();
        completedTaskList = new ArrayList<>();
        taskAdapter = new TaskAdapter(taskList, this, completedTaskList, pendingTaskList); // 创建适配器并传入任务列表

        recyclerView.setAdapter(taskAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fab = findViewById(R.id.fab); // 获取添加任务按钮
        fab.setOnClickListener(v -> showAddTaskDialog());

        // 设置 Spinner 的适配器
        Spinner filterSpinner = findViewById(R.id.filterSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.filter_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        filterSpinner.setAdapter(adapter);

        // 监听 Spinner 的选择变化
        filterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // 根据选择更新 RecyclerView
                filterTasks(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // 不做任何操作
            }

        });



        // 添加 ItemTouchHelper
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {

            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                int fromPosition = viewHolder.getBindingAdapterPosition();
                int toPosition = target.getBindingAdapterPosition();
                taskAdapter.onItemMove(fromPosition, toPosition);
                return true; // 返回 true 表示移动成功
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                // 不处理滑动事件
            }
        });

        itemTouchHelper.attachToRecyclerView(recyclerView);

        ImageButton searchButton = findViewById(R.id.searchButton);
        searchButton.setOnClickListener(v -> openSearchActivity());
    }

    private void showAddTaskDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Task");
        final EditText input = new EditText(this);
        builder.setView(input);
        builder.setPositiveButton("Add", (dialog, which) -> {
            String taskName = input.getText().toString();
            if (!taskName.isEmpty()) {
                Task newTask = new Task(taskName);
                pendingTaskList.add(newTask); // 添加到未完成任务列表
                taskList.add(newTask); // 添加到主要任务列表
                taskAdapter.notifyItemInserted(taskList.size() - 1);

                Log.d("MainActivity", "Pending tasks size: " + pendingTaskList.size());
                Log.d("MainActivity", "All tasks size: " + taskList.size());

                Log.d("MainActivity", "Added task: " + taskName); // 记录添加任务
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    //筛选
    private void filterTasks(int position) {
        List<Task> filteredTasks = new ArrayList<>();
        switch (position) {
            case 0: // 显示所有任务
                filteredTasks.addAll(pendingTaskList);
                filteredTasks.addAll(completedTaskList);
                Log.d("MainActivity", "Filtering all tasks");
                break;
            case 1: // 仅显示未完成的任务
                filteredTasks.addAll(pendingTaskList);
                Log.d("MainActivity", "Filtering pending tasks");
                break;
            case 2: // 仅显示已完成的任务
                filteredTasks.addAll(completedTaskList);
                Log.d("MainActivity", "Filtering completed tasks");
                break;
        }
        taskAdapter.updateTaskList(filteredTasks); // 更新适配器中的任务列表
        Log.d("MainActivity", "Filtered task count: " + filteredTasks.size());
    }

    private void openSearchActivity() {
        Intent intent = new Intent(this, SearchActivity.class);
        intent.putExtra("ALL_TASKS", new ArrayList<>(taskList)); // 传递所有任务
        startActivity(intent);
    }
}
