package com.in6222.final_project_chenzijia;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox; // 确保导入 CheckBox
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private List<Task> taskList;

    public TaskAdapter(List<Task> taskList) {
        this.taskList = taskList;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.task_item, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.taskNameTextView.setText(task.getTaskName());

        // 根据任务的完成状态设置复选框
        holder.taskCheckBox.setChecked(task.isCompleted()); // 设置复选框状态

        // 清除之前的监听器，以避免状态混乱
        holder.taskCheckBox.setOnCheckedChangeListener(null);

        // 设置复选框的点击事件
        holder.taskCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            task.setCompleted(isChecked); // 更新任务的完成状态
        });

        // 设置删除按钮的点击事件
        holder.deleteButton.setOnClickListener(v -> {
            if (position >= 0 && position < taskList.size()) { // 检查索引有效性
                taskList.remove(position);
                notifyItemRemoved(position); // 更新适配器
                notifyItemRangeChanged(position, taskList.size()); // 更新后续项的索引
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size(); // 返回任务列表的大小
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView taskNameTextView; // 任务名称的 TextView
        CheckBox taskCheckBox; // 复选框引用
        ImageButton deleteButton; // 删除按钮引用

        public TaskViewHolder(View itemView) {
            super(itemView);
            taskNameTextView = itemView.findViewById(R.id.taskNameTextView); // 初始化任务名称 TextView
            taskCheckBox = itemView.findViewById(R.id.taskCheckBox); // 初始化复选框
            deleteButton = itemView.findViewById(R.id.deleteButton); // 初始化删除按钮
        }
    }
}

