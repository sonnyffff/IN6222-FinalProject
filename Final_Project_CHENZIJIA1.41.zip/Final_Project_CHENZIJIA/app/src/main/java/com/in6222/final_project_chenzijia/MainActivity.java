package com.in6222.final_project_chenzijia;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.in6222.final_project_chenzijia.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private static final int SEARCH_REQUEST_CODE = 1;
    private ActivityMainBinding binding;
    private TaskAdapter taskAdapter;
    private List<Task> taskList; // tasks to be shown
    private List<Task> pendingTaskList;
    private List<Task> completedTaskList;

    private TaskDatabaseHelper dbHelper; // initialize dbHelper to store data locally

    private static int nextId = 1; // not in use
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater()); // initialize View Binding
        setContentView(binding.getRoot());
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));

        taskList = new ArrayList<>();
        pendingTaskList = new ArrayList<>();
        completedTaskList = new ArrayList<>();
        taskAdapter = new TaskAdapter(taskList, this, completedTaskList, pendingTaskList); // create new task adapter

        binding.recyclerView.setAdapter(taskAdapter);

        taskAdapter.setupItemTouchHelper(binding.recyclerView);

        binding.fab.setOnClickListener(v -> showAddTaskDialog()); // add task

        // Spinner for filtering
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.filter_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.filterSpinner.setAdapter(adapter);

        binding.filterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // update RecyclerView base on selection
                filterTasks(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // do nothing
            }

        });


        // search
        binding.searchButton.setOnClickListener(v -> openSearchActivity());

        // database
        dbHelper = new TaskDatabaseHelper(this);

        loadTasks(); // load task from database
    }

    private void loadTasks() {
        List<Task> allTasks = dbHelper.getAllTasks(); // load all tasks from db
        pendingTaskList.clear();
        completedTaskList.clear();

        for (Task task : allTasks) {
            if (task.isCompleted()) {
                completedTaskList.add(task);
            } else {
                pendingTaskList.add(task);
            }
        }

        taskList.clear();
        taskList.addAll(allTasks);
        taskAdapter.notifyDataSetChanged();
        Log.d("MainActivity", "Loaded tasks from database: " + allTasks.size());
    }

    // adding
    private void showAddTaskDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Task");
        final EditText input = new EditText(this);
        builder.setView(input);
        builder.setPositiveButton("Add", (dialog, which) -> {
            String taskName = input.getText().toString();
            if (!taskName.isEmpty()) {
                Task newTask = new Task(nextId++, taskName);
                pendingTaskList.add(newTask);
                taskList.add(newTask);
                dbHelper.addTask(newTask); //add to database
                taskAdapter.notifyItemInserted(taskList.size() - 1);

                Log.d("MainActivity", "Pending tasks size: " + pendingTaskList.size());
                Log.d("MainActivity", "All tasks size: " + taskList.size());

                Log.d("MainActivity", "Added task: " + taskName);
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // filtering
    private void filterTasks(int position) {
        List<Task> filteredTasks = new ArrayList<>();
        switch (position) {
            case 0: // show all tasks
                filteredTasks.addAll(pendingTaskList);
                filteredTasks.addAll(completedTaskList);
                Log.d("MainActivity", "Filtering all tasks");
                break;
            case 1: // show pending tasks
                filteredTasks.addAll(pendingTaskList);
                Log.d("MainActivity", "Filtering pending tasks");
                break;
            case 2: // show completed tasks
                filteredTasks.addAll(completedTaskList);
                Log.d("MainActivity", "Filtering completed tasks");
                break;
        }
        taskAdapter.updateTaskList(filteredTasks);
        Log.d("MainActivity", "Filtered task count: " + filteredTasks.size());
    }

    // searching
    private void openSearchActivity() {
        Intent intent = new Intent(this, SearchActivity.class);
        List<Task> allTasks = new ArrayList<>();
        allTasks.addAll(pendingTaskList);
        allTasks.addAll(completedTaskList);

        intent.putExtra("ALL_TASKS", (Serializable) allTasks); // pass all tasks to search
        startActivityForResult(intent, SEARCH_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SEARCH_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                List<Task> updatedTasks = (List<Task>) data.getSerializableExtra("UPDATED_TASK_LIST"); // get returning task list
                if (updatedTasks != null) {
                    pendingTaskList.clear();
                    completedTaskList.clear();

                    for (Task task : updatedTasks) {
                        if (task.isCompleted()) {
                            completedTaskList.add(task);
                        } else {
                            pendingTaskList.add(task);
                        }
                    }
                    int selectedPosition = binding.filterSpinner.getSelectedItemPosition();
                    switch (selectedPosition) {
                        case 0: // show all tasks
                            taskList.clear();
                            taskList.addAll(updatedTasks);
                            break;
                        case 1: // show pending tasks
                            taskList.clear();
                            taskList.addAll(pendingTaskList);
                            break;
                        case 2: // show completed tasks
                            taskList.clear();
                            taskList.addAll(completedTaskList);
                            break;
                    }
                    taskAdapter.notifyDataSetChanged();
                    Log.d("MainActivity", "Updated task list size: " + updatedTasks.size());
                } else {
                    Log.d("MainActivity", "Updated task list is null");
                }
            }
        }
    }


}
