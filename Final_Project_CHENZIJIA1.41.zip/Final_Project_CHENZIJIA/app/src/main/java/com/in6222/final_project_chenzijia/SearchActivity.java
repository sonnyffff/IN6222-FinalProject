package com.in6222.final_project_chenzijia;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.in6222.final_project_chenzijia.databinding.ActivitySearchBinding;

public class SearchActivity extends AppCompatActivity {
    private ActivitySearchBinding binding; // create View Binding object
    private TaskAdapter taskAdapter;
    private List<Task> allTasks;
    private List<Task> filteredTasks; // search result

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.searchResultsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        allTasks = (List<Task>) getIntent().getSerializableExtra("ALL_TASKS");
        filteredTasks = new ArrayList<>();

        taskAdapter = new TaskAdapter(filteredTasks, this, new ArrayList<>(), new ArrayList<>());
        binding.searchResultsRecyclerView.setAdapter(taskAdapter);

        // add TextWatcher
        binding.searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterTasks(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        binding.backButton.setOnClickListener(v -> returnUpdatedTasks());// return to main activity
    }

    // filtering tasks base on user input
    private void filterTasks(String query) {

        filteredTasks.clear();

        List<Task> filteredTasks = new ArrayList<>();
        if (query.isEmpty()) {
            // if the box is empty, show nothing
            taskAdapter.updateTaskList(new ArrayList<>());
        } else {
            for (Task task : allTasks) {
                if (task.getTaskName().toLowerCase().contains(query)) {
                    filteredTasks.add(task);
                }
            }

            taskAdapter.updateTaskList(filteredTasks);
        }

    }

    // return tasks back to main
    private void returnUpdatedTasks() {
        Intent returnIntent = new Intent();
        returnIntent.putExtra("UPDATED_TASK_LIST", (Serializable) allTasks);
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }
}


