package com.in6222.final_project_chenzijia;

import java.io.Serializable;

public class Task implements Serializable {

    private String taskName;
    private boolean isCompleted;
    private int id; // currently not in use

    public Task(int id, String taskName) {
        this.id = id;
        this.taskName = taskName;
        this.isCompleted = false;
    }

    public String getTaskName() {
        return taskName;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public int getId() {
        return id;
    }

}
