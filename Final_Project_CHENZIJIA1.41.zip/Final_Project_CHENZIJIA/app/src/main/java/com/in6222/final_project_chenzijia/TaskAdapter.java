package com.in6222.final_project_chenzijia;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.EditText;
import android.app.AlertDialog;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.List;
import android.util.Log;

import com.google.android.material.snackbar.Snackbar;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private List<Task> taskList;
    private Context context;
    private List<Task> completedTaskList; // store completed task list
    private List<Task> pendingTaskList; // store pending task list

    private TaskDatabaseHelper dbHelper; // SQLite db

    public TaskAdapter(List<Task> taskList, Context context, List<Task> completedTaskList, List<Task> pendingTaskList) {
        this.taskList = taskList;
        this.context = context;
        this.completedTaskList = completedTaskList;
        this.pendingTaskList = pendingTaskList;

        this.dbHelper = new TaskDatabaseHelper(context); // initialize database
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.task_item, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.taskNameTextView.setText(task.getTaskName());

        // click task name to update
        holder.taskNameTextView.setOnClickListener(v -> showEditTaskDialog(task, holder.getBindingAdapterPosition()));

        holder.taskCheckBox.setOnCheckedChangeListener(null); // first remove listener
        holder.taskCheckBox.setChecked(task.isCompleted()); // set status of task

        holder.taskCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            task.setCompleted(isChecked);
            Log.d("TaskAdapter", "Task: " + task.getTaskName() + " checked: " + isChecked);

            // use post method to make sure update is made after RecyclerView layout
            holder.taskCheckBox.post(() -> {
                if (isChecked) {
                    // move from pending list to completed list
                    pendingTaskList.remove(task);
                    completedTaskList.add(task);
                } else {
                    // move from completed list to pending list
                    completedTaskList.remove(task);
                    pendingTaskList.add(task);
                }
                // update SQLite database
                dbHelper.updateTask(task);
                // update RecyclerView
                notifyDataSetChanged();
            });
        });

    }

    // user gestures
    public void setupItemTouchHelper(RecyclerView recyclerView) {
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                int fromPosition = viewHolder.getBindingAdapterPosition();
                int toPosition = target.getBindingAdapterPosition();
                if (fromPosition != RecyclerView.NO_POSITION && toPosition != RecyclerView.NO_POSITION) {
                    // handling task position movement
                    onItemMove(fromPosition, toPosition);
                    return true;
                }
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    deleteTask(position, recyclerView);
                }
            }

            @Override
            public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                // customize background effect of swipe actions
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
                    Paint paint = new Paint();
                    if (dX < 0) { // left swipe
                        paint.setColor(Color.RED); // red bg
                        c.drawRect(viewHolder.itemView.getRight() + dX, viewHolder.itemView.getTop(), viewHolder.itemView.getRight(), viewHolder.itemView.getBottom(), paint);

                        // trashcan icon
                        Bitmap trashIcon = BitmapFactory.decodeResource(recyclerView.getResources(), R.drawable.img);
                        if (trashIcon != null) {
                            float iconWidth = trashIcon.getWidth();
                            float iconHeight = trashIcon.getHeight();
                            float iconMargin = (viewHolder.itemView.getHeight() - iconHeight) / 2;
                            c.drawBitmap(trashIcon, viewHolder.itemView.getRight() - iconWidth - 16, viewHolder.itemView.getTop() + iconMargin, null);
                        } else {
                            Log.e("TaskAdapter", "Error: trash icon is null. Check if the resource exists.");
                        }
                    }
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            }
        });

        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

public void deleteTask(int position, RecyclerView recyclerView) {
    if (position >= 0 && position < taskList.size()) {
        Task removedTask = taskList.get(position);
        taskList.remove(position);

        // check if list is in completed list
        if (completedTaskList.contains(removedTask)) {
            completedTaskList.remove(removedTask);
        } else {
            pendingTaskList.remove(removedTask);
        }

        notifyItemRemoved(position);
        dbHelper.deleteTask(removedTask.getTaskName(), removedTask.isCompleted()); // delete from data base

        // undo Snackbar
        Snackbar snackbar = Snackbar.make(recyclerView, "Task deleted", Snackbar.LENGTH_LONG)
                .setAction("UNDO", v -> {
                    // click to undo
                    taskList.add(position, removedTask); // add back task
                    if (removedTask.isCompleted()) {
                        completedTaskList.add(removedTask);
                    } else {
                        pendingTaskList.add(removedTask);
                    }
                    dbHelper.addTask(removedTask);
                    notifyItemInserted(position);
                });
        snackbar.show();
    }
}

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView taskNameTextView;
        CheckBox taskCheckBox;
        // ImageButton deleteButton;

        public TaskViewHolder(View itemView) {
            super(itemView);
            taskNameTextView = itemView.findViewById(R.id.taskNameTextView);
            taskCheckBox = itemView.findViewById(R.id.taskCheckBox);
            //deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    // click to rename
    private void showEditTaskDialog(Task task, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Task");
        String oname = task.getTaskName();

        final EditText input = new EditText(context);
        input.setText(task.getTaskName());
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String updatedTaskName = input.getText().toString();
            if (!updatedTaskName.isEmpty()) {
                task.setTaskName(updatedTaskName); // update task name
                dbHelper.updateTask2(oname, task); // update db
                notifyItemChanged(position);
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
    
    // hold and drag to move task position
    public void onItemMove(int fromPosition, int toPosition) {
        // check index range
        if (fromPosition < 0 || toPosition < 0 || fromPosition >= taskList.size() || toPosition >= taskList.size()) {
            return; // out of bound
        }

        Log.d("TaskAdapter", "Moving from position: " + fromPosition + " to position: " + toPosition);
        Log.d("TaskAdapter", "Current task list size: " + taskList.size());

        // positioning logic
        if (fromPosition < toPosition) {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(taskList, i, i + 1);
            }
        } else {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(taskList, i, i - 1);
            }
        }

        notifyItemMoved(fromPosition, toPosition);
    }

    // for sorting..
    public void updateTaskList(List<Task> newTaskList) {
        this.taskList.clear();
        this.taskList.addAll(newTaskList);
        notifyDataSetChanged();
    }


}
