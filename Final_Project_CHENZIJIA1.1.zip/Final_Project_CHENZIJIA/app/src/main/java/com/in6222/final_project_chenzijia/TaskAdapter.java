package com.in6222.final_project_chenzijia;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.EditText;
import android.app.AlertDialog;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.ItemTouchHelper;

import java.util.Collections;
import java.util.List;
import android.util.Log;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private List<Task> taskList;
    private Context context;

    public TaskAdapter(List<Task> taskList, Context context) {
        this.taskList = taskList;
        this.context = context;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.task_item, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.taskNameTextView.setText(task.getTaskName());
        holder.taskCheckBox.setChecked(task.isCompleted());

        // 点击任务名称以编辑
        holder.taskNameTextView.setOnClickListener(v -> showEditTaskDialog(task, holder.getBindingAdapterPosition()));

        holder.taskCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            task.setCompleted(isChecked);
        });

        // 删除按钮的点击事件
        holder.deleteButton.setOnClickListener(v -> {
            int pos = holder.getBindingAdapterPosition(); // 获取当前任务的位置
            if (pos != RecyclerView.NO_POSITION) { // 确保位置有效
                deleteTask(pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    public void deleteTask(int position) {
        if (position >= 0 && position < taskList.size()) {
            taskList.remove(position);
            notifyItemRemoved(position); // 通知适配器删除
        }
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView taskNameTextView;
        CheckBox taskCheckBox;
        ImageButton deleteButton;

        public TaskViewHolder(View itemView) {
            super(itemView);
            taskNameTextView = itemView.findViewById(R.id.taskNameTextView);
            taskCheckBox = itemView.findViewById(R.id.taskCheckBox);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    // 单击名称修改
    private void showEditTaskDialog(Task task, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Task");

        // 输入框
        final EditText input = new EditText(context);
        input.setText(task.getTaskName());
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String updatedTaskName = input.getText().toString();
            if (!updatedTaskName.isEmpty()) {
                task.setTaskName(updatedTaskName); // 更新任务名称
                notifyItemChanged(position); // 通知适配器更新
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
    
    // 添加拖动功能
    public void onItemMove(int fromPosition, int toPosition) {
        // 检查索引范围
        if (fromPosition < 0 || toPosition < 0 || fromPosition >= taskList.size() || toPosition >= taskList.size()) {
            return; // 超出范围，不处理
        }

        // 输出调试信息
        Log.d("TaskAdapter", "Moving from position: " + fromPosition + " to position: " + toPosition);
        Log.d("TaskAdapter", "Current task list size: " + taskList.size());

        // 处理移动逻辑
        if (fromPosition < toPosition) {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(taskList, i, i + 1);
            }
        } else {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(taskList, i, i - 1);
            }
        }

        // 通知适配器更新
        notifyItemMoved(fromPosition, toPosition);
    }


}
